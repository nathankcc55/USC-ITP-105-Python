# Nathan Chan, channath@usc.edu
# ITP 115, Spring 2021
# Assignment 1
# Description: This program tells you two truths and a lie
# Answers are expressed by these data types: strings, booleans, and integers

# Variables are created here. str(), bool() and int() are not necessary when there is no user input

first = "Nathan Kai Ching"
last = "Chan"
statement1 = "Squash is my favorite sport."
statement2 = "I enjoy playing video games."
statement3 = "I can speak 5 languages."
truth1 = True
truth2 = True
truth3 = False
pets = 1
siblings = 2

# Printing the variables, and using escape characters to create new lines
# I learned about f-string while searching for ways to help with formatting Lab 1
# I liked it and decided to use it for this assignment

print(f"Full name: {first} {last} \n")
print(f"Number of pets: {pets} \n"
      f"Number of siblings: {siblings} \n")
print(f"Statement 1: {statement1} \n"
      f"Statement 2: {statement2} \n"
      f"Statement 3: {statement3} \n")
print(f"Statement 1 is {truth1} \n"
      f"Statement 2 is {truth2} \n"
      f"Statement 3 is {truth3}")
