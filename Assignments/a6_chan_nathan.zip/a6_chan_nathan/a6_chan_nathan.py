# Nathan Chan, channath@usc.edu
# ITP 115, Spring 2021
# Assignment 6
# Description: This program asks the user to guess the jumbled word, as well as a Caesar cipher

import random

# Part 1: Word Jumble Game
# Define variables for possible jumbled words and their respective hints
theList = ["playstation", "basketball", "sociology", "spotify", "marius"]
wordHint = ["A video game console", "LeBron is the greatest __________ player",
        "The study of society and the human interactions within it", "A digital streaming platform",
        "Held the office of consul seven times under the Roman Republic"]

# Select a word from the list and make a new list to separate individual letters that form the word
word = random.choice(theList)
answer = word
jumble = list(word)
jumbleIndex = theList.index(word)

# This for loop swaps the letters or index with another in the list, starting from 0 (first) to the last index
for letter in range(len(jumble)):
    index = random.randrange(0, len(jumble))
    temp = jumble[letter]
    jumble[letter] = jumble[index]
    jumble[index] = temp

# Join the index to form a single string
jumbledWord = "".join(jumble)

# Print the jumbled word and ask the user to guess the original word by input
print("Part 1: Word Jumble Game\n")
print("The jumbled word is", "\"" + jumbledWord + "\"")

# Variable to count the amount points and guesses, answer to be incorrect, and the hints to be used later
attempts = 0
score = 15
hint = False
correct = False

# As long as the user does not have the answer, then the loop will run
while not correct:
    guess = input("Please enter your guess: ").lower()

    # Attempt goes up and loop ends because answer is correct
    if guess == answer:
        print("You got it!")
        attempts += 1
        correct = True

    # Try again, and attempt goes up
    else:
        print("Try again.")
        attempts += 1

    # If the user has used two attempts or more, program will ask the user if they need hint
    if attempts >= 2 and not correct:

        # Program will stop asking if you need a hint when you answer y or n
        answerHelp = False
        while answerHelp is False:
            getHelp = input("Would you like a hint? (y/n): ").lower()

            # Index positions for theList and wordHint are manually sorted. Hence, hint index = word index
            if getHelp == "y":
                print("The hint for this word:", wordHint[jumbleIndex])
                hint = True
                answerHelp = True
            # End this while loop
            elif getHelp == "n":
                answerHelp = True
            # Continue while loop, tell the user they need to answer y or n only
            else:
                print("Invalid answer. Only answer " "\"y\"" + " or " + "\"n\"" + ".")

# First try means the user gets 15 as their score, which is the maximum score possible.
if attempts == 1:
    print("It took you", attempts, "try.")
    print("Your score is", score, "because it was your first try!")

# Two different possible scores if the user attempts more than once. Either way, 5 points are deducted at first.
elif attempts > 1:
    score -= 5
    print("It took you", attempts, "tries.")

    # If the user used a hint, another 5 points are deducted from the score. In total, 10 points deducted from score.
    if hint:
        score -= 5
        print("Your score is", score, "because it was not your first try and you used the hint.")

    # The user will not lose points if hints were never used. In total, 5 points deducted from score.
    elif not hint:
        print("Your score is", score, "because it was not your first try.")

# Part 2: Encrypt / Decrypt
print("")
print("Part 2: Encrypt / Decrypt\n")
# Create a list to store letters and ask for two user inputs. The string input will be lower cased
shiftedlist = []
prompt = input("Enter a message: ").lower()
shift = int(input("Enter a number to shift by (0-25): "))

# Analyzes every character from the prompt input.
for i in prompt:

    # For alphabets, it will take the shift value to append a new alphabet based on ASCII value differences
    if i.isalpha():
        encrypted = chr((ord(i) - 97 + shift) % 26 + 97)
        shiftedlist.append(encrypted)

    # Anything besides an alphabet will just be appended to the list. For instance, whitespace and numbers.
    else:
        shiftedlist.append(i)

# This variable takes each item in the list and joins it with the quotation marks, making it a string
encryptedprompt = "".join(shiftedlist)

# Printing first part of the program
print("Encrypting message....")
print("     Encrypted message:", encryptedprompt)

# This new list will be used for decrypting
reversedlist = shiftedlist

# Taking the values of the shifter1 string for decryption
for j in encryptedprompt:

    # Removes the original alphabets and creates a new variable to append alphabets with opposite shift difference
    if j.isalpha():
        reversedlist.remove(chr((ord(j) - 97) % 26 + 97))
        decrypted = chr((ord(j) - 97 - shift) % 26 + 97)
        reversedlist.append(decrypted)
    # The for loop will always keep the list in the original order if it addresses the non-alphabets as well
    else:
        reversedlist.remove(j)
        reversedlist.append(j)

decryptedprompt = "".join(reversedlist)

# Printing second half of the output
print("Decrypting message....")
print("     Decrypted message:", decryptedprompt)
print("     Original message:", prompt)