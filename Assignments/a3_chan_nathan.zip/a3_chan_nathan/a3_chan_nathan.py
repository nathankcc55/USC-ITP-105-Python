# Nathan Chan, channath@usc.edu
# ITP 115, Spring 2021
# Assignment 3
# Description: This program illustrates a vending machine and involves calculations with discounts and change.

# Set the initial values for certain variables
cost = int(0)
shared = int(0)
galleon = int(493)

# Ask the user for which item they would like to buy
print("Please select an item from the vending machine:")
print("    a) Butterbeer: 58 knuts")
print("    b) Quill: 10 knuts")
print("    c) The Daily Prophet: 7 knuts")
print("    d) Book of Spells: 400 knuts")
item = input("> ")

# this if statement asks the user to choose between the 5 options below or else it will warn the user to redo the answer
# This will also set the value of the "cost" variable depending on the item choice
if item.lower() == "a":
    item = "Butterbeer"
    cost = int(58)
elif item.lower() == "b":
    item = "Quill"
    cost = int(10)
elif item.lower() == "c":
    item = "The Daily Prophet"
    cost = int(7)
elif item.lower() == "d":
    item = "Book of Spells"
    cost = int(400)
else:
    while item.lower() != "a" and item.lower() != "b" and item.lower() != "c" and item.lower() != "d":
        print("You have entered an invalid option. Please try again.")
        print("Please select an item from the vending machine:")
        print("    a) Butterbeer: 58 knuts")
        print("    b) Quill: 10 knuts")
        print("    c) The Daily Prophet: 7 knuts")
        print("    d) Book of Spells: 400 knuts")
        item = input("> ")

# this if statement asks a yes or no for sharing on instagram, and incorrect answers will repeat the question
# It also creates the discount and shared variables, and both are used for the final output
instagram = input("Will you share this on instagram (y/n)? ")
if instagram.lower() == "y":
    cost = cost - int(5)
    shared = int(5)
    print("Thank you! You get 5 knuts off your purchase.")
    print("\n")
elif instagram.lower() == "n":
    shared = int(0)
    print("\n")
else:
    while instagram.lower() != "y" and instagram.lower() != "n":
        print("That is an invalid answer, try again.")
        instagram = input("Will you share this on instagram (y/n)? ")

# These variables are used to calculate the final cost and change received
change = galleon - cost
sicklefinal = change // int(29)
knutfinal = change % int(29)

# This is the final output as a result of the calculations above
print("You bought a " + item + " for " + str(cost) + " knuts (With a coupon of " + str(shared) +
      " knuts) and paid with one galleon.")
print("Here is your change (" + str(change) + " knuts):")
print("Sickles: " + str(sicklefinal))
print("Knuts: " + str(knutfinal))
