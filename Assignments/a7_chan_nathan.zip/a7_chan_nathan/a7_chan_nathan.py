# Nathan Chan, channath@usc.edu
# ITP 115, Spring 2021
# Assignment 7
# Description:
# This program allows for the user to play rock, paper, scissors against the computer

import random   # Necessary module

# These two lists of strings are ordered and each value corresponds to an integer later
gameChoice = ["Rock", "Paper", "Scissors"]
choiceDescription = ["Rock smashes scissors", "Paper covers rock", "Scissors cut paper"]


# Utilizes all the other functions
def main():

    # Variables for counting game results
    playerWin = 0
    playerLose = 0
    playerTie = 0

    # Defines this variable as a boolean type
    playGame = True

    # Loops the game until the user decides to stop playing
    while playGame:

        # Call for the instructions
        displayMenu()

        # Create local variables to obtain the return values from other functions
        playerNum = getPlayerChoice()
        computerNum = getComputerChoice()
        result = playRound(computerNum, playerNum)

        # An output to inform the user of the player and computer selections between rock, paper and scissors
        print("You chose " + str(gameChoice[playerNum]) + ".")
        print("The computer chose", str(gameChoice[computerNum]) + ".")

        # Add a count to player's ties.
        if result == 0:
            print("Tie game!")
            playerTie += 1

        # Add a count to player's wins.
        elif result == 1:
            print(str(choiceDescription[playerNum]) + ". Player wins!")
            playerWin += 1

        # Add a count to player's losses.
        elif result == -1:
            print(str(choiceDescription[computerNum]) + ". Computer wins!")
            playerLose += 1

        # Local variable that calls for the function for continuing / ending the game
        playGame = continueGame()

        # Presents final results, and ends the program because it exits
        if not playGame:
            print("")
            print("You won " + str(playerWin) + " game(s).")
            print("The computer won " + str(playerLose) + " game(s).")
            print("You tied with the computer " + str(playerTie) + " time(s).")
            print("\nThanks for playing!")


# Displays instructions to play the game
def displayMenu():
    print("Welcome! Let's play rock, paper, scissors."
          "\nThe rules of the game are:"
          "\n   Rock smashes scissors"
          "\n   Scissors cut paper"
          "\n   Paper covers rock"
          "\n   If both the choices are the same, it's a tie")


# The computer is given a random number from 0 to 2. Returns an integer from 0 to 2.
def getComputerChoice():
    computer_number = random.randint(0, 2)

    return computer_number


# The player has to select a number from 0 to 2. Returns the integer based on user input.
def getPlayerChoice():
    print("Please choose (0) for rock, (1) for paper or (2) for scissors")
    player_number = input("> ")
    while player_number != "0" and player_number != "1" and player_number != "2":
        player_number = input("> ")

    return int(player_number)


# Two inputs indicating a relation between a computer and player's integer. Returns one of three possible integers.
def playRound(computerChoice, playerChoice):

    # The player and computer have the same object for the game
    if computerChoice == playerChoice:
        return 0

    # The computer has the object that beats the player's object
    elif (computerChoice == 0 and playerChoice == 2) or \
            (computerChoice == 1 and playerChoice == 0) or \
            (computerChoice == 2 and playerChoice == 1):
        return -1

    # The player has the object that beats the computer's object
    else:
        return 1


# See if user wishes to continue playing the game. Returns boolean.
def continueGame():
    userContinue = input("Do you want to continue playing (y or n)? ")
    while userContinue.lower() != "y" and userContinue.lower() != "n":
        print("Invalid answer.")
        userContinue = input("Do you want to continue playing (y or n)?")
    if userContinue.lower() == "y":
        print("")
        return True
    else:
        return False


# Call the main function
main()
