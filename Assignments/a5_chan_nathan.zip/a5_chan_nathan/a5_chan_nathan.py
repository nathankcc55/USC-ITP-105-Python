# Nathan Chan, channath@usc.edu
# ITP 115, Spring 2021
# Assignment 5
# Description: This program prints the frequency of characters based on the user input using for loops
# Also, a D20 (dice rolling with 20 sides) game

import random

# This is part 1 of the assignment
specialchar = 0
print("PART 1 - Character Counter")
sentence = input("Please enter a sentence: ")
print("\nHere is the character distribution:\n")
print("Special characters: ", end="")

# The first for loop will process the special characters from the user input
for i in sentence:
    if ord(i) >= 33:
        if 91 <= ord(i) <= 96:
            specialchar += 1
        elif 65 <= ord(i) <= 122:
            pass
        else:
            specialchar += 1
if specialchar >= 1:
    for j in range(specialchar):
        print("*", end="")
else:
    print("NONE")
print("")

# The next for loop does the same but for alphabets. It will convert capital letters to lowercase with -32 to ASCII
for k in range(97, 123):
    alphabetchar = 0
    print(chr(k) + ": ", end="")
    for l in sentence:
        if l == chr(k) or l == chr(k-32):
            alphabetchar += 1
    if alphabetchar >= 1:
        for m in range(alphabetchar):
            print("*", end="")
        print("")
    else:
        print("NONE")

# Below is part 2 of this week's assignment. A D20 dice rolling program that is played ten times.
finalscore = 0
print("\nPART 2 - D20 Dice Game\n")
# This for function loops the number of rounds, possible cases and sides of the dice 10 times.
for n in range(1, 11, 1):
    d20 = random.randrange(1, 21, 1)
    case = random.randrange(1, 6, 1)
    print("You are playing for CASE", case)
    print("You will win with the following numbers:")
# Defining the range of numbers for each case
    if case == 1:
        for win in range(2, 21, 2):
            print(win, end="  ")
    elif case == 2:
        for win in range(1, 21, 2):
            print(win, end="  ")
    elif case == 3:
        for win in range(5, 11, 1):
            print(win, end="  ")
    elif case == 4:
        for win in range(10, 21, 2):
            print(win, end="  ")
    elif case == 5:
        for win in range(3, 21, 3):
            print(win, end="  ")

    winner = False
    print("\n\nNow rolling ...")
    print("You rolled a " + str(d20) + "!")
# If a number in the case matches the dice roll, then you win and get 50 points. Otherwise, you are not a winner.
    if case == 1:
        for win in range(2, 21, 2):
            if win == d20:
                finalscore += 50
                winner = True
    elif case == 2:
        for win in range(1, 21, 2):
            if win == d20:
                finalscore += 50
                winner = True
    elif case == 3:
        for win in range(5, 11, 1):
            if win == d20:
                finalscore += 50
                winner = True
    elif case == 4:
        for win in range(10, 21, 2):
            if win == d20:
                finalscore += 50
                winner = True
    elif case == 5:
        for win in range(3, 21, 3):
            if win == d20:
                finalscore += 50
                winner = True

    if winner:
        print("You won 50 points! :)\n")
    else:
        print("You didn't win :(\n")

print("Your total score is:", finalscore)
print("Thanks for playing!")
