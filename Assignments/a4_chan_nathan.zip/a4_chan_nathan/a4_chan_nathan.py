# Nathan Chan, channath@usc.edu
# ITP 115, Spring 2021
# Assignment 4
# Description: This program t

again = "y"

while again.lower() == "y":
    print("Input an integer greater than or equal to 0 (-1 to quit)")
    usernumber = int(input("> "))
    maximum = usernumber
    minimum = usernumber
    total = 0
    count = 0

    while usernumber != -1:
        if usernumber > maximum:
            maximum = usernumber
            total = total + usernumber
            count = count + 1
        elif usernumber < minimum:
            minimum = usernumber
            total = total + usernumber
            count = count + 1
        else:
            total = total + usernumber
            count = count + 1
        usernumber = int(input("> "))
    else:
        average = total / count
        print("The largest number is " + str(maximum))
        print("The smallest number is " + str(minimum))
        print("The average number is " + str(average))

    print("\n")
    again = input("Would you like to enter another set of numbers? (y/n):")
    if again.lower() != "y":
        print("Goodbye!")
